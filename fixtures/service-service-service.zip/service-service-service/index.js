"use strict";
const router = require("@arangodb/foxx/router")();
module.context.use(router);

router.get((req, res) => {
  res.json({
    local: {
      dir: module.context.fileName("services/minimal-working-service"),
      js: module.context.fileName("services/minimal-working-service/index.js"),
      zip: module.context.fileName("services/minimal-working-service.zip")
    },
    remote: {
      js: req.makeAbsolute("js"),
      zip: req.makeAbsolute("zip")
    }
  });
});

router.get("js", (req, res) => {
  res.download(
    module.context.fileName("services/minimal-working-service/index.js")
  );
});

router.get("zip", (req, res) => {
  res.download(module.context.fileName("services/minimal-working-service.zip"));
});
