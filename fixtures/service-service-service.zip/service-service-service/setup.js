"use strict";
const utils = require("@arangodb/foxx/manager-utils");

utils.zipDirectory(
  module.context.fileName("services/minimal-working-service"),
  module.context.fileName("services/minimal-working-service.zip")
);
