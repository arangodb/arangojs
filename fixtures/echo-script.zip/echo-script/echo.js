'use strict';
module.exports = module.context.argv;
