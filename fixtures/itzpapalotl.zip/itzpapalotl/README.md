itzpapalotl
===========

This ia a simple example application written for ArangoDB-Foxx.
It returns a random Aztec deity name.

The application provides a simple REST API with the following methods:
* `GET /itzpapalotl/index`: shows an HTML overview page
* `GET /itzpapalotl/random`: returns a random deity name as JSON
* `GET /itzpapalotl/{deity}/summon`: summon a deity

